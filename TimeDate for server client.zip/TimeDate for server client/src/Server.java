  

import java.io.*;  
import java.net.*;

public class Server {
    
    public static void main(String[] args) throws IOException {
        
        ServerSocket serverSocket = new ServerSocket(915);  
         System.out.println("Server Started...");
        
        while(true){
          
           Socket socket = serverSocket.accept();  
          
           DataInputStream inp = new DataInputStream(socket.getInputStream());  
           DataOutputStream out = new DataOutputStream(socket.getOutputStream());  

           String buttonPressed = inp.readUTF();  

           if(buttonPressed.equals("date")){  
               String date = new java.util.Date().toString();  
               out.writeUTF(date);  
           }
           else if(buttonPressed.equals("time")){
               String time = new java.util.Date().toString();  
               out.writeUTF(time);  
           }
       
           socket.close();
        }  
    }
}