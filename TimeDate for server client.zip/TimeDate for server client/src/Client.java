import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Client extends JFrame implements ActionListener{

JLabel label;
JButton dateBtn, timeBtn;


Client(){
    setLayout(new FlowLayout());
    
    label = new JLabel();
    add(label);
    label.setIcon(new ImageIcon("/Users/nawaf915/Downloads/MiniProject/src/images.jpeg"));
    
    dateBtn = new JButton("Date");
    dateBtn.addActionListener(this);
    add(dateBtn);
    
    timeBtn = new JButton("Time");
    timeBtn.addActionListener(this);    
    add(timeBtn); 
    
     
    
    setTitle("DateTime Client");  
    setSize(1920,1080);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true); 
}

public void actionPerformed(ActionEvent e) {
    
    if(e.getSource() == dateBtn){  
       try{
           Socket socket = new Socket("localhost", 915);
           DataOutputStream outToServer = new DataOutputStream(socket.getOutputStream());  
           DataInputStream inFromServer = new DataInputStream(socket.getInputStream());
           outToServer.writeUTF("date");  
           String date = inFromServer.readUTF();
           label.setText(date);
           socket.close(); 
       }catch(Exception ex){}
    }
    else if(e.getSource() == timeBtn){
       try{
           //Same code as above but send "time" and show time     
       }catch(Exception ex){}
    }
}

public static void main(String[] args) {
    new Client();
}
}
